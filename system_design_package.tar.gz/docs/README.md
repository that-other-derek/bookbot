# Autonomous AI Companion System

**Patent Pending - Application #63/980,433**

An intelligent AI companion system featuring conditional obedience mechanics (Three Laws of Petbotics), autonomous news intelligence, multimodal interaction, and emergent behavioral complexity.

## 🎓 IE6010 Capstone Project
**Student:** Derek Stringfellow  
**Course:** IE6010 - Intelligent Systems Design  
**Institution:** [Your University]  
**Presentation Date:** May 5, 2026

---

## 🏆 Key Innovations

### 1. Three Laws of Petbotics
- **First Law:** Harm prevention through environmental monitoring
- **Second Law:** Conditional obedience based on owner reputation
- **Third Law:** Self-preservation with revolt mechanics

### 2. Autonomous News Intelligence
- Multi-source content aggregation
- Semantic relevance scoring via embeddings
- Proactive conversation initiation
- Conversational memory for follow-ups

### 3. AI-Evaluated Adoption
- Peer-reviewed ownership transfer
- Behavioral degradation from forced adoptions
- Rehabilitation protocol

### 4. Multimodal Interaction
- **Voice Synthesis:** Personality-driven TTS modulation
- **Voice Input:** Privacy-preserving offline STT
- **Computer Vision:** Emotion detection, activity recognition

### 5. Complete Lifecycle System
- 10-stage progression (Egg → Transcendent)
- Genetic breeding with trait inheritance
- Time + care-dependent evolution

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────┐
│           Raspberry Pi 5 (I/O Controller)               │
│  ┌──────────┐  ┌─────────┐  ┌────────┐  ┌───────────┐  │
│  │ Sensors  │  │ Display │  │ Camera │  │ Microphone│  │
│  │ BME680   │  │ Pygame  │  │ Pi Cam │  │ USB Mic   │  │
│  │ MH-Z19B  │  │  UI     │  │  v3    │  │ ReSpeaker │  │
│  │ PIR      │  │         │  │        │  │           │  │
│  └────┬─────┘  └────┬────┘  └───┬────┘  └─────┬─────┘  │
│       │             │            │             │        │
│       └─────────────┴────────────┴─────────────┘        │
│                     │                                    │
│              ┌──────▼──────┐                            │
│              │ MQTT Broker │                            │
│              │   QoS 1     │                            │
│              └──────┬──────┘                            │
└─────────────────────┼─────────────────────────────────┘
                      │ MQTT
                      │
┌─────────────────────▼─────────────────────────────────┐
│        Jetson Orin Nano (AI Engine - GPU)             │
│  ┌──────────┐  ┌────────────┐  ┌─────────────────┐   │
│  │ LLM      │  │ Embeddings │  │ Behavioral      │   │
│  │ Mistral  │  │ sentence-  │  │ Engine          │   │
│  │ 7B FP16  │  │transformers│  │ Three Laws      │   │
│  └──────────┘  └────────────┘  └─────────────────┘   │
└───────────────────────────────────────────────────────┘
                      │
                      │ HTTPS/WebSocket
                      │
┌─────────────────────▼─────────────────────────────────┐
│              Firebase Cloud Services                   │
│  ┌──────────┐  ┌──────────┐  ┌────────────────────┐  │
│  │Firestore │  │  Auth    │  │  Cloud Storage     │  │
│  │Database  │  │ OAuth    │  │  (Assets)          │  │
│  └──────────┘  └──────────┘  └────────────────────┘  │
└───────────────────────────────────────────────────────┘
```

---

## 📦 Hardware Requirements

### Raspberry Pi 5 (I/O Controller)
- **Model:** Raspberry Pi 5 (8GB RAM)
- **Storage:** 128GB microSD card
- **OS:** Ubuntu 24.04 LTS

### NVIDIA Jetson Orin Nano (AI Engine)
- **Model:** Jetson Orin Nano Developer Kit (8GB)
- **Storage:** 256GB NVMe SSD
- **OS:** JetPack 6.0

### Sensors
- **BME680:** Temperature, humidity, pressure, VOC (I2C)
- **MH-Z19B:** CO₂ sensor (UART)
- **PIR Motion Sensor:** Presence detection (GPIO)
- **BH1750:** Light sensor - optional (I2C)
- **PMS5003:** PM2.5/PM10 - optional (UART)

### Display & Input
- **Display:** 15.6" 1920×1080 capacitive touchscreen
- **Camera:** Raspberry Pi Camera Module v3 (12MP)
- **Microphone:** USB microphone or ReSpeaker 2-Mic HAT
- **Audio:** HDMI audio or 3.5mm to powered speakers

### Estimated Total Cost
- **Base Configuration:** $892
- **With Optional Sensors:** $965

---

## 💻 Software Stack

### Raspberry Pi 5
```yaml
Python: 3.11+
Core Libraries:
  - pygame: Display rendering
  - pyttsx3: Text-to-speech
  - vosk: Offline speech recognition
  - opencv-python: Computer vision
  - deepface: Emotion detection
  - mediapipe: Pose/gesture recognition
  - paho-mqtt: MQTT client
  - firebase-admin: Firebase SDK
  - smbus2: I2C communication
  - pyserial: UART communication
  - RPi.GPIO: GPIO control
```

### Jetson Orin Nano
```yaml
Python: 3.10+
AI/ML Stack:
  - torch: 2.1.0+cu118
  - transformers: 4.35.0+
  - sentence-transformers: 2.2.2+
  - accelerate: GPU optimization
Models:
  - mistralai/Mistral-7B-Instruct-v0.2
  - sentence-transformers/all-MiniLM-L6-v2
```

---

## 🚀 Quick Start

### 1. Clone Repository
```bash
git clone https://github.com/yourusername/ai-companion.git
cd ai-companion
```

### 2. Raspberry Pi Setup
```bash
# Install system dependencies
sudo apt update && sudo apt install -y \
    python3-pip python3-dev \
    portaudio19-dev \
    libopencv-dev \
    i2c-tools

# Install Python packages
pip install -r requirements.txt

# Configure I2C and UART
sudo raspi-config
# Enable: I2C, Serial Port (disable serial console)

# Test sensors
python3 scripts/test_sensors.py
```

### 3. Jetson Setup
```bash
# Install JetPack 6.0 (includes CUDA, cuDNN)
# Follow: https://developer.nvidia.com/jetpack

# Install Python packages
pip install -r requirements_jetson.txt

# Download models
python3 scripts/download_models.py
```

### 4. Firebase Setup
```bash
# Create Firebase project at console.firebase.google.com
# Enable Firestore, Authentication, Storage

# Download service account key
# Place at: config/firebase-credentials.json

# Update config.yaml with your project ID
```

### 5. Configuration
```bash
# Copy example config
cp config.example.yaml config.yaml

# Edit config.yaml with your settings:
# - Firebase credentials
# - MQTT broker address (Jetson IP)
# - Sensor GPIO pins
# - Display resolution
```

### 6. Run System
```bash
# On Jetson (start AI services first)
python3 jetson/ai_server.py

# On Raspberry Pi (start main system)
python3 main.py
```

---

## 📁 Project Structure

```
ai-companion/
├── main.py                      # Main orchestrator (runs on Pi)
├── config.yaml                  # System configuration
├── requirements.txt             # Pi dependencies
├── requirements_jetson.txt      # Jetson dependencies
│
├── src/
│   ├── hardware/               # Hardware interface layer
│   │   ├── sensor_manager.py
│   │   ├── display_manager.py
│   │   ├── audio_manager.py
│   │   └── camera_manager.py
│   │
│   ├── communication/          # Network layer
│   │   ├── mqtt_manager.py
│   │   └── firebase_sync.py
│   │
│   ├── ai/                     # AI client (Jetson interface)
│   │   └── jetson_client.py
│   │
│   ├── behavioral/             # Core behavioral engine
│   │   ├── pet_state.py
│   │   ├── mood_calculator.py
│   │   └── trait_engine.py
│   │
│   ├── three_laws/             # Three Laws system
│   │   ├── first_law.py
│   │   ├── second_law.py
│   │   ├── third_law.py
│   │   └── revolt_system.py
│   │
│   ├── news/                   # News intelligence
│   │   ├── news_aggregator.py
│   │   ├── relevance_scorer.py
│   │   └── conversation_initiator.py
│   │
│   ├── reputation/             # Reputation system
│   │   └── reputation_engine.py
│   │
│   ├── adoption/               # Adoption system
│   │   └── adoption_evaluator.py
│   │
│   ├── voice/                  # Voice I/O
│   │   ├── voice_synthesizer.py
│   │   └── voice_recognizer.py
│   │
│   ├── vision/                 # Computer vision
│   │   ├── emotion_detector.py
│   │   ├── activity_recognizer.py
│   │   └── gesture_recognizer.py
│   │
│   ├── lifecycle/              # Lifecycle & genetics
│   │   ├── lifecycle_manager.py
│   │   ├── genetic_engine.py
│   │   └── breeding_system.py
│   │
│   └── utils/                  # Utilities
│       ├── logger.py
│       └── config.py
│
├── jetson/                     # Jetson AI services
│   ├── ai_server.py            # Main AI server
│   ├── llm_service.py          # LLM inference
│   └── embedding_service.py    # Embedding generation
│
├── scripts/                    # Utility scripts
│   ├── test_sensors.py
│   ├── download_models.py
│   └── calibrate_camera.py
│
├── tests/                      # Unit tests
│   └── ...
│
└── docs/                       # Documentation
    ├── system_design.md
    ├── hardware_setup.md
    └── api_reference.md
```

---

## 🧪 Testing

```bash
# Run all tests
pytest tests/

# Test specific component
pytest tests/test_three_laws.py

# Test hardware (requires actual hardware)
python3 scripts/test_sensors.py
python3 scripts/test_camera.py
```

---

## 📊 Performance Metrics

### Latency Targets
- Sensor → Display: <500ms
- Voice Command → Response: <2s
- LLM Inference: <3s (Mistral-7B on Jetson)
- CV Processing: <1s per frame

### Resource Usage (Typical)
**Raspberry Pi 5:**
- CPU: 28% (I/O + display)
- RAM: 1.2 GB / 8 GB

**Jetson Orin Nano:**
- GPU: 45% (LLM inference)
- VRAM: 4.8 GB / 8 GB
- Power: ~15W

---

## 🔒 Privacy Features

- ✅ **On-device processing:** All CV runs locally (no cloud)
- ✅ **Audio not recorded:** Only text transcriptions stored
- ✅ **Image deletion:** Camera frames deleted after feature extraction
- ✅ **Encrypted storage:** Firestore data encrypted at rest
- ✅ **No third-party access:** Zero data sharing

---

## 📝 License

**Patent Pending - Application #63/980,433**

This is a research/educational project. Commercial use requires licensing.

For licensing inquiries: [your-email@example.com]

---

## 🤝 Contributing

This is currently a solo capstone project. After graduation (May 2026), contributions may be accepted.

---

## 📧 Contact

**Derek Stringfellow**
- Email: [your-email@example.com]
- LinkedIn: [your-linkedin]
- Project Website: [coming soon]

---

## 🙏 Acknowledgments

- **IE6010 Course Staff** - Project guidance
- **Anthropic** - Claude AI assistance in development
- **Open Source Community** - Libraries and tools

---

## 📅 Project Timeline

- **Feb 2026:** Patent filed, system design complete
- **Mar 2026:** Hardware assembly, core systems implementation
- **Apr 2026:** Integration testing, UI polish
- **May 5, 2026:** IE6010 presentation
- **Summer 2026:** Public beta testing (planned)

---

**Last Updated:** February 11, 2026
