"""Sensor Manager - Handles all environmental sensors via I2C, UART, GPIO"""
class SensorManager:
    def __init__(self, config): pass
    async def start(self): pass
    async def stop(self): pass
    async def read_all(self): pass
    def on_update(self, callback): pass
