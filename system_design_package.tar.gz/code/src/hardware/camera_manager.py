"""Camera Manager - Pi Camera Module interface"""
class CameraManager:
    def __init__(self, config): pass
    async def start(self): pass
    async def stop(self): pass
    async def capture(self): pass
