"""Audio Manager - Audio output control"""
class AudioManager:
    def __init__(self, config): pass
    async def start(self): pass
    async def stop(self): pass
    def play(self, audio_data): pass
