"""Display Manager - Pygame-based UI rendering"""
class DisplayManager:
    def __init__(self, config): pass
    async def start(self): pass
    async def stop(self): pass
    async def render(self, pet_state): pass
    def update_mood_indicator(self, mood): pass
    def show_revolt_screen(self): pass
