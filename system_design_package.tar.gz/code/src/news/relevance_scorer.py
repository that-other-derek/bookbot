"""Relevance Scorer - Score articles via embeddings"""
class RelevanceScorer:
    def __init__(self, ai_client, pet_state): pass
    async def score(self, article): return 0.0
    def on_article_scored(self, callback): pass
