"""Conversation Initiator - Decide when to share news"""
class ConversationInitiator:
    def __init__(self, pet_state, ai_client): pass
    async def evaluate(self, article, relevance): pass
