"""Voice Recognizer - STT with wake word"""
class VoiceRecognizer:
    def __init__(self, config, on_command): 
        self.on_command = on_command
    def start(self): pass
    def stop(self): pass
