"""MQTT Manager - QoS 1 message passing to Jetson"""
class MQTTManager:
    def __init__(self, config): pass
    async def connect(self): pass
    async def disconnect(self): pass
    def publish(self, topic, message): pass
    def subscribe(self, topic, callback): pass
