"""Jetson AI Client - MQTT interface to AI processing"""
class JetsonAIClient:
    def __init__(self, mqtt_client, config): pass
    def has_pending_requests(self): return False
    async def process_next(self): pass
    def request_llm(self, prompt, callback=None): pass
