"""Emotion Detector - DeepFace emotion detection"""
class EmotionDetector:
    def __init__(self, camera, pet_state): pass
    async def process(self, frame): pass
    def on_emotion_detected(self, callback): pass
