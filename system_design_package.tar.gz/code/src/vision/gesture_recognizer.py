"""Gesture Recognizer - MediaPipe hand tracking"""
class GestureRecognizer:
    def __init__(self, camera, on_gesture): 
        self.on_gesture = on_gesture
    async def process(self, frame): pass
