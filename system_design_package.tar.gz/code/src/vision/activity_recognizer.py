"""Activity Recognizer - MediaPipe pose estimation"""
class ActivityRecognizer:
    def __init__(self, camera): pass
    async def process(self, frame): pass
    def on_activity_change(self, callback): pass
