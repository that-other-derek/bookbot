"""Second Law Evaluator - Conditional obedience"""
class SecondLawEvaluator:
    def __init__(self, pet, first_law): pass
    def evaluate_command(self, command, owner_score): 
        return {'obey': True, 'response': 'Okay!'}
