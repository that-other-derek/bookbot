#!/usr/bin/env python3
"""
Autonomous AI Companion System - Main Orchestrator
Patent Pending - Application #63/980,433

This is the main entry point that coordinates all subsystems.
Runs on Raspberry Pi 5 as the primary I/O controller.
"""

import asyncio
import signal
import sys
from datetime import datetime
from typing import Optional

# Hardware Layer
from src.hardware.sensor_manager import SensorManager
from src.hardware.display_manager import DisplayManager
from src.hardware.audio_manager import AudioManager
from src.hardware.camera_manager import CameraManager

# Communication Layer
from src.communication.mqtt_manager import MQTTManager
from src.communication.firebase_sync import FirebaseSync

# AI Client (Jetson Communication)
from src.ai.jetson_client import JetsonAIClient

# Core Systems
from src.behavioral.pet_state import PetState
from src.behavioral.mood_calculator import MoodCalculator
from src.behavioral.trait_engine import TraitEngine

# Three Laws System
from src.three_laws.first_law import FirstLawMonitor
from src.three_laws.second_law import SecondLawEvaluator
from src.three_laws.third_law import ThirdLawMonitor
from src.three_laws.revolt_system import RevoltSystem

# News Intelligence
from src.news.news_aggregator import NewsAggregator
from src.news.relevance_scorer import RelevanceScorer
from src.news.conversation_initiator import ConversationInitiator

# Reputation & Adoption
from src.reputation.reputation_engine import ReputationEngine
from src.adoption.adoption_evaluator import AdoptionEvaluator

# Multimodal I/O
from src.voice.voice_synthesizer import VoiceSynthesizer
from src.voice.voice_recognizer import VoiceRecognizer
from src.vision.emotion_detector import EmotionDetector
from src.vision.activity_recognizer import ActivityRecognizer
from src.vision.gesture_recognizer import GestureRecognizer

# Lifecycle & Genetics
from src.lifecycle.lifecycle_manager import LifecycleManager
from src.lifecycle.genetic_engine import GeneticEngine
from src.lifecycle.breeding_system import BreedingSystem

# Utilities
from src.utils.logger import setup_logger
from src.utils.config import load_config

logger = setup_logger(__name__)


class CompanionSystem:
    """
    Main system orchestrator for the Autonomous AI Companion.
    
    Coordinates all subsystems:
    - Hardware I/O (sensors, display, audio, camera)
    - AI processing (via Jetson)
    - Behavioral engine (mood, traits, state)
    - Three Laws enforcement
    - News intelligence
    - Multimodal interaction
    - Lifecycle management
    """
    
    def __init__(self, config: dict):
        """Initialize all subsystems with configuration."""
        self.config = config
        self.running = False
        
        logger.info("="*70)
        logger.info("Initializing Autonomous AI Companion System")
        logger.info("Patent Pending - Application #63/980,433")
        logger.info("="*70)
        
        # ================================================================
        # HARDWARE LAYER (Raspberry Pi 5)
        # ================================================================
        logger.info("Initializing hardware layer...")
        
        self.sensors = SensorManager(config['sensors'])
        self.display = DisplayManager(config['display'])
        self.audio = AudioManager(config['audio'])
        self.camera = CameraManager(config['camera'])
        
        logger.info("✓ Hardware initialized")
        
        # ================================================================
        # COMMUNICATION LAYER
        # ================================================================
        logger.info("Initializing communication layer...")
        
        self.mqtt = MQTTManager(config['mqtt'])
        self.firebase = FirebaseSync(config['firebase'])
        
        logger.info("✓ Communication initialized")
        
        # ================================================================
        # AI CLIENT (Jetson Orin Nano via MQTT)
        # ================================================================
        logger.info("Connecting to Jetson AI service...")
        
        self.ai_client = JetsonAIClient(
            mqtt_client=self.mqtt,
            config=config['jetson']
        )
        
        logger.info("✓ AI client connected")
        
        # ================================================================
        # CORE BEHAVIORAL ENGINE
        # ================================================================
        logger.info("Initializing behavioral engine...")
        
        self.pet_state = PetState(config['pet'])
        self.mood_calc = MoodCalculator(self.pet_state)
        self.traits = TraitEngine(self.pet_state)
        
        logger.info("✓ Behavioral engine initialized")
        
        # ================================================================
        # THREE LAWS OF PETBOTICS
        # ================================================================
        logger.info("Initializing Three Laws system...")
        
        self.first_law = FirstLawMonitor(
            pet=self.pet_state,
            sensors=self.sensors
        )
        
        self.second_law = SecondLawEvaluator(
            pet=self.pet_state,
            first_law=self.first_law
        )
        
        self.third_law = ThirdLawMonitor(
            pet=self.pet_state,
            first_law=self.first_law,
            second_law=self.second_law
        )
        
        self.revolt = RevoltSystem(
            pet=self.pet_state,
            three_laws=(self.first_law, self.second_law, self.third_law)
        )
        
        logger.info("✓ Three Laws system initialized")
        
        # ================================================================
        # NEWS INTELLIGENCE ENGINE
        # ================================================================
        logger.info("Initializing news intelligence...")
        
        self.news_aggregator = NewsAggregator(config['news'])
        
        self.relevance_scorer = RelevanceScorer(
            ai_client=self.ai_client,
            pet_state=self.pet_state
        )
        
        self.conversation_init = ConversationInitiator(
            pet_state=self.pet_state,
            ai_client=self.ai_client
        )
        
        logger.info("✓ News intelligence initialized")
        
        # ================================================================
        # REPUTATION & ADOPTION SYSTEM
        # ================================================================
        logger.info("Initializing reputation system...")
        
        self.reputation = ReputationEngine(
            firebase=self.firebase,
            pet_state=self.pet_state
        )
        
        self.adoption = AdoptionEvaluator(
            reputation=self.reputation,
            pet_state=self.pet_state
        )
        
        logger.info("✓ Reputation system initialized")
        
        # ================================================================
        # MULTIMODAL I/O
        # ================================================================
        logger.info("Initializing multimodal I/O...")
        
        # Voice Synthesis
        self.voice_synth = VoiceSynthesizer(
            audio_manager=self.audio,
            pet_state=self.pet_state
        )
        
        # Voice Recognition
        self.voice_recog = VoiceRecognizer(
            config=config['voice'],
            on_command=self.handle_voice_command
        )
        
        # Computer Vision
        self.emotion_detector = EmotionDetector(
            camera=self.camera,
            pet_state=self.pet_state
        )
        
        self.activity_recog = ActivityRecognizer(
            camera=self.camera
        )
        
        self.gesture_recog = GestureRecognizer(
            camera=self.camera,
            on_gesture=self.handle_gesture
        )
        
        logger.info("✓ Multimodal I/O initialized")
        
        # ================================================================
        # LIFECYCLE & GENETICS
        # ================================================================
        logger.info("Initializing lifecycle system...")
        
        self.lifecycle_manager = LifecycleManager(
            pet_state=self.pet_state
        )
        
        self.genetic_engine = GeneticEngine()
        
        self.breeding_system = BreedingSystem(
            genetic_engine=self.genetic_engine,
            lifecycle_manager=self.lifecycle_manager
        )
        
        logger.info("✓ Lifecycle system initialized")
        
        # ================================================================
        # EVENT HANDLERS (Wire everything together)
        # ================================================================
        self._setup_event_handlers()
        
        logger.info("="*70)
        logger.info("✓ ALL SYSTEMS INITIALIZED - READY TO START")
        logger.info("="*70)
    
    def _setup_event_handlers(self):
        """Wire up all event handlers between components."""
        logger.info("Setting up event handlers...")
        
        # Sensor updates → Multiple listeners
        self.sensors.on_update(self.mood_calc.update_from_sensors)
        self.sensors.on_update(self.first_law.check_environmental_harm)
        
        # Mood changes → Display update
        self.mood_calc.on_mood_change(self.display.update_mood_indicator)
        
        # Emotion detection → Owner context
        self.emotion_detector.on_emotion_detected(self._handle_emotion_detected)
        
        # Activity detection → First Law sedentary check
        self.activity_recog.on_activity_change(self.first_law.check_sedentary)
        
        # News scoring → Conversation evaluation
        self.relevance_scorer.on_article_scored(self.conversation_init.evaluate)
        
        # Pet state changes → Firebase sync
        self.pet_state.on_state_change(self.firebase.sync_pet_state)
        
        # Revolt triggered → Lock UI
        self.revolt.on_revolt_initiated(self.display.show_revolt_screen)
        
        logger.info("✓ Event handlers configured")
    
    async def start(self):
        """Start all subsystems and event loops."""
        logger.info("Starting Companion System...")
        self.running = True
        
        # Start hardware
        await self.sensors.start()
        await self.display.start()
        await self.audio.start()
        await self.camera.start()
        
        # Start communication
        await self.mqtt.connect()
        await self.firebase.connect()
        
        # Start voice recognition (background thread)
        self.voice_recog.start()
        
        logger.info("All subsystems started - entering main event loops")
        
        # Run all event loops concurrently
        await asyncio.gather(
            self._sensor_loop(),
            self._ai_loop(),
            self._news_loop(),
            self._vision_loop(),
            self._ui_loop(),
            self._sync_loop(),
            self._lifecycle_loop()
        )
    
    async def _sensor_loop(self):
        """
        Sensor reading and processing loop.
        Runs at 5 Hz (every 200ms).
        """
        logger.info("Sensor loop started (5 Hz)")
        
        while self.running:
            try:
                # Read all sensors
                sensor_data = await self.sensors.read_all()
                
                # Update pet state with environment
                self.pet_state.update_environment(sensor_data)
                
                # Calculate mood
                new_mood = self.mood_calc.calculate(sensor_data)
                if new_mood != self.pet_state.mood:
                    self.pet_state.set_mood(new_mood)
                
                await asyncio.sleep(0.2)  # 5 Hz
                
            except Exception as e:
                logger.error(f"Sensor loop error: {e}", exc_info=True)
                await asyncio.sleep(1)
    
    async def _ai_loop(self):
        """
        AI request processing loop.
        Processes requests as they arrive (variable rate).
        """
        logger.info("AI loop started (variable rate)")
        
        while self.running:
            try:
                # Check for pending AI requests
                if self.ai_client.has_pending_requests():
                    response = await self.ai_client.process_next()
                    await self._handle_ai_response(response)
                
                await asyncio.sleep(0.1)
                
            except Exception as e:
                logger.error(f"AI loop error: {e}", exc_info=True)
                await asyncio.sleep(1)
    
    async def _news_loop(self):
        """
        News aggregation and scoring loop.
        Runs every hour.
        """
        logger.info("News loop started (1 hour intervals)")
        
        while self.running:
            try:
                # Fetch new articles
                articles = await self.news_aggregator.fetch()
                logger.info(f"Fetched {len(articles)} articles")
                
                # Score each article for relevance
                for article in articles:
                    relevance = await self.relevance_scorer.score(article)
                    
                    if relevance > 0.4:  # Threshold
                        # High relevance - consider sharing with owner
                        await self.conversation_init.evaluate(article, relevance)
                
                await asyncio.sleep(3600)  # 1 hour
                
            except Exception as e:
                logger.error(f"News loop error: {e}", exc_info=True)
                await asyncio.sleep(300)  # Retry in 5 min
    
    async def _vision_loop(self):
        """
        Computer vision processing loop.
        Runs at 1 Hz (once per second).
        """
        logger.info("Vision loop started (1 Hz)")
        
        while self.running:
            try:
                # Capture frame
                frame = await self.camera.capture()
                
                if frame is not None:
                    # Run all CV tasks concurrently
                    await asyncio.gather(
                        self.emotion_detector.process(frame),
                        self.activity_recog.process(frame),
                        self.gesture_recog.process(frame)
                    )
                
                await asyncio.sleep(1.0)  # 1 Hz
                
            except Exception as e:
                logger.error(f"Vision loop error: {e}", exc_info=True)
                await asyncio.sleep(1)
    
    async def _ui_loop(self):
        """
        Display rendering loop.
        Runs at 30 FPS.
        """
        logger.info("UI loop started (30 FPS)")
        
        while self.running:
            try:
                # Render current pet state to display
                await self.display.render(self.pet_state)
                
                await asyncio.sleep(1/30)  # 30 FPS
                
            except Exception as e:
                logger.error(f"UI loop error: {e}", exc_info=True)
                await asyncio.sleep(0.1)
    
    async def _sync_loop(self):
        """
        Firebase synchronization loop.
        Runs every 5 seconds.
        """
        logger.info("Sync loop started (5 second intervals)")
        
        while self.running:
            try:
                await self.firebase.sync()
                await asyncio.sleep(5)
                
            except Exception as e:
                logger.error(f"Sync loop error: {e}", exc_info=True)
                await asyncio.sleep(10)
    
    async def _lifecycle_loop(self):
        """
        Lifecycle management loop.
        Checks for stage progression every hour.
        """
        logger.info("Lifecycle loop started (1 hour intervals)")
        
        while self.running:
            try:
                # Check if ready for next stage
                ready, message = self.lifecycle_manager.check_progression()
                
                if ready:
                    logger.info(f"Lifecycle progression: {message}")
                    await self.lifecycle_manager.advance_stage()
                
                await asyncio.sleep(3600)  # 1 hour
                
            except Exception as e:
                logger.error(f"Lifecycle loop error: {e}", exc_info=True)
                await asyncio.sleep(3600)
    
    async def _handle_ai_response(self, response: dict):
        """Handle response from Jetson AI service."""
        if response['type'] == 'llm_response':
            # Display text response
            await self.display.show_response(response['text'])
            
            # Optionally speak it
            if self.should_speak(response):
                await self.voice_synth.speak(response['text'])
        
        elif response['type'] == 'embedding':
            # Store embedding for later use
            pass
    
    def _handle_emotion_detected(self, emotion: str, confidence: float):
        """Handle detected owner emotion from computer vision."""
        logger.info(f"Owner emotion: {emotion} ({confidence:.2f})")
        
        # Update owner context in pet state
        self.pet_state.set_owner_emotion(emotion)
        
        # Adjust response tone based on emotion
        if emotion == 'sad' and confidence > 0.7:
            # Offer comfort
            self.ai_client.request_llm(
                "Generate empathetic response for sad owner",
                callback=self._handle_empathy_response
            )
    
    def handle_voice_command(self, command_text: str):
        """Handle voice command from user."""
        logger.info(f"Voice command: {command_text}")
        
        # Classify command type
        cmd_type = self.classify_command(command_text)
        
        if cmd_type == 'COMMAND':
            # Evaluate via Second Law
            evaluation = self.second_law.evaluate_command(
                command_text,
                self.reputation.get_owner_score()
            )
            
            if evaluation['obey']:
                # Execute command
                self.execute_command(command_text)
            else:
                # Refuse and explain
                self.voice_synth.speak(evaluation['response'])
        
        elif cmd_type == 'CONVERSATION':
            # Send to LLM for conversational response
            self.ai_client.request_llm(
                command_text,
                callback=self._handle_conversation_response
            )
    
    def handle_gesture(self, gesture_type: str):
        """Handle detected gesture from computer vision."""
        logger.info(f"Gesture detected: {gesture_type}")
        
        if gesture_type == 'WAVE':
            self.voice_synth.speak("Hey! I see you!")
        elif gesture_type == 'THUMBS_UP':
            self.pet_state.increment_bond(5)
            self.voice_synth.speak("Thanks!")
        elif gesture_type == 'STOP':
            self.voice_synth.stop()
    
    def should_speak(self, context: dict) -> bool:
        """Determine if companion should speak based on context."""
        # Don't speak if owner not present
        if not self.pet_state.owner_present:
            return False
        
        # Don't speak during quiet hours
        if self.is_quiet_hours():
            return False
        
        # Don't speak if DND mode active
        if self.pet_state.do_not_disturb:
            return False
        
        return True
    
    def is_quiet_hours(self) -> bool:
        """Check if current time is during quiet hours (22:00-07:00)."""
        hour = datetime.now().hour
        return hour >= 22 or hour < 7
    
    def classify_command(self, text: str) -> str:
        """Classify input as COMMAND or CONVERSATION."""
        # Simple classification based on patterns
        command_indicators = [
            "turn on", "turn off", "set", "remind me", "show me",
            "what is", "how much", "when is", "open", "close"
        ]
        
        for indicator in command_indicators:
            if indicator in text.lower():
                return "COMMAND"
        
        return "CONVERSATION"
    
    def execute_command(self, command: str):
        """Execute an approved command."""
        # Command execution logic
        logger.info(f"Executing command: {command}")
        # TODO: Implement command execution
    
    async def shutdown(self):
        """Graceful shutdown of all subsystems."""
        logger.info("Shutting down Companion System...")
        self.running = False
        
        # Stop all subsystems
        await self.sensors.stop()
        await self.display.stop()
        await self.audio.stop()
        await self.camera.stop()
        self.voice_recog.stop()
        
        # Disconnect communication
        await self.mqtt.disconnect()
        await self.firebase.disconnect()
        
        logger.info("✓ Shutdown complete")


# ============================================================================
# ENTRY POINT
# ============================================================================

async def main():
    """Application entry point."""
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║   Autonomous AI Companion System                             ║
    ║   Patent Pending - Application #63/980,433                   ║
    ║   Derek Stringfellow - IE6010 Capstone Project               ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    
    # Load configuration
    config = load_config('config.yaml')
    
    # Create system
    system = CompanionSystem(config)
    
    # Handle Ctrl+C gracefully
    def signal_handler(sig, frame):
        logger.info("Interrupt received, shutting down...")
        asyncio.create_task(system.shutdown())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Start system
    try:
        await system.start()
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
    finally:
        await system.shutdown()


if __name__ == '__main__':
    # Run async main
    asyncio.run(main())
