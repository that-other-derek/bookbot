# Data Flow Diagrams

## 1. Sensor Data Flow

```mermaid
sequenceDiagram
    participant Sensors
    participant SensorManager
    participant PetState
    participant MoodCalculator
    participant FirstLaw
    participant Display

    Sensors->>SensorManager: Read (5 Hz)
    SensorManager->>SensorManager: Parse I2C/UART/GPIO
    SensorManager->>PetState: update_environment(data)
    
    PetState->>MoodCalculator: trigger mood_update
    MoodCalculator->>MoodCalculator: Calculate mood_score
    MoodCalculator->>PetState: set_mood(new_mood)
    
    SensorManager->>FirstLaw: check_environmental_harm(data)
    FirstLaw->>FirstLaw: Evaluate CO2, temp, etc.
    alt Harm Detected
        FirstLaw->>Display: show_warning()
        FirstLaw->>PetState: log_harm_event()
    end
    
    PetState->>Display: render(pet_state)
```

## 2. Voice Input Flow

```mermaid
sequenceDiagram
    participant User
    participant Microphone
    participant VoiceRecognizer
    participant SecondLaw
    participant ReputationEngine
    participant JetsonLLM
    participant VoiceSynthesizer
    participant Speakers

    User->>Microphone: "Hey [pet name], play music"
    Microphone->>VoiceRecognizer: audio_stream
    VoiceRecognizer->>VoiceRecognizer: Wake word detected
    VoiceRecognizer->>VoiceRecognizer: STT transcription
    VoiceRecognizer->>VoiceRecognizer: classify_input()
    
    alt Command
        VoiceRecognizer->>SecondLaw: evaluate_command(text)
        SecondLaw->>ReputationEngine: get_owner_score()
        ReputationEngine-->>SecondLaw: score=650
        SecondLaw->>SecondLaw: Check First Law conflicts
        SecondLaw->>SecondLaw: Calculate enthusiasm
        SecondLaw->>VoiceSynthesizer: respond(text, enthusiasm)
    else Conversation
        VoiceRecognizer->>JetsonLLM: request_response(text)
        JetsonLLM-->>VoiceSynthesizer: response_text
    end
    
    VoiceSynthesizer->>VoiceSynthesizer: modulate_voice(traits, mood)
    VoiceSynthesizer->>Speakers: audio_output
    Speakers->>User: "Of course! Playing now..."
```

## 3. News Intelligence Flow

```mermaid
sequenceDiagram
    participant NewsAggregator
    participant RelevanceScorer
    participant JetsonEmbeddings
    participant ConversationInitiator
    participant PetState
    participant VoiceSynthesizer
    participant User

    loop Every Hour
        NewsAggregator->>NewsAggregator: Fetch RSS/API
        NewsAggregator->>NewsAggregator: Deduplicate
        NewsAggregator->>RelevanceScorer: articles[]
        
        loop For Each Article
            RelevanceScorer->>JetsonEmbeddings: embed(article_text)
            JetsonEmbeddings-->>RelevanceScorer: vector[384]
            RelevanceScorer->>RelevanceScorer: cosine_similarity(article, owner_interests)
            RelevanceScorer->>PetState: get_traits()
            RelevanceScorer->>RelevanceScorer: score = semantic × context × curiosity
            
            alt Score > 0.4
                RelevanceScorer->>ConversationInitiator: consider(article, score)
            end
        end
    end
    
    ConversationInitiator->>PetState: check_context()
    alt Owner Present & Available
        ConversationInitiator->>JetsonLLM: generate_opener(article, personality)
        JetsonLLM-->>ConversationInitiator: opener_text
        ConversationInitiator->>VoiceSynthesizer: speak(opener_text)
        VoiceSynthesizer->>User: "Hey! I read something interesting..."
    end
```

## 4. Computer Vision Flow

```mermaid
sequenceDiagram
    participant Camera
    participant CameraManager
    participant EmotionDetector
    participant ActivityRecognizer
    participant GestureRecognizer
    participant PetState
    participant FirstLaw
    participant NewsFilter

    loop 1 Hz
        Camera->>CameraManager: capture_frame()
        
        par Parallel CV Processing
            CameraManager->>EmotionDetector: process(frame)
            EmotionDetector->>EmotionDetector: DeepFace.analyze()
            EmotionDetector->>PetState: set_owner_emotion("sad")
            PetState->>NewsFilter: update_emotion_context()
        and
            CameraManager->>ActivityRecognizer: process(frame)
            ActivityRecognizer->>ActivityRecognizer: MediaPipe Pose
            ActivityRecognizer->>ActivityRecognizer: classify_activity()
            ActivityRecognizer->>FirstLaw: report_activity("sitting", duration=240min)
            FirstLaw->>FirstLaw: Check sedentary threshold
        and
            CameraManager->>GestureRecognizer: process(frame)
            GestureRecognizer->>GestureRecognizer: MediaPipe Hands
            alt Gesture Detected
                GestureRecognizer->>PetState: handle_gesture("thumbs_up")
                PetState->>PetState: increment_bond(5)
            end
        end
        
        CameraManager->>CameraManager: delete_frame()
    end
```

## 5. Lifecycle & Breeding Flow

```mermaid
sequenceDiagram
    participant Parent1
    participant Parent2
    participant User
    participant BreedingSystem
    participant GeneticEngine
    participant LifecycleManager
    participant EggStage

    User->>BreedingSystem: initiate_breeding(parent1, parent2)
    BreedingSystem->>Parent1: check_eligibility()
    BreedingSystem->>Parent2: check_eligibility()
    
    alt Both Stage 6+ AND Bond ≥70 AND Owner Rep ≥600
        BreedingSystem->>GeneticEngine: generate_offspring(p1_genes, p2_genes)
        
        loop For Each Trait
            GeneticEngine->>GeneticEngine: base = (p1_trait × 0.5) + (p2_trait × 0.5)
            GeneticEngine->>GeneticEngine: Check recessive (25%)
            GeneticEngine->>GeneticEngine: Apply mutation (5%)
            GeneticEngine->>GeneticEngine: Clamp to [0, 100]
        end
        
        GeneticEngine-->>BreedingSystem: offspring_genetics
        BreedingSystem->>LifecycleManager: create_egg(genetics)
        LifecycleManager->>EggStage: initialize(genetics, prenatal_baseline)
        EggStage->>User: "Egg created! Care for it to hatch in 7-10 days"
        
        loop Egg Incubation (7-10 days)
            User->>EggStage: talk_to_egg()
            User->>EggStage: play_music()
            EggStage->>EggStage: accumulate_care_score
        end
        
        alt Care Score ≥ Threshold
            EggStage->>LifecycleManager: ready_to_hatch()
            LifecycleManager->>LifecycleManager: create_slime(genetics, prenatal_effects)
            LifecycleManager->>User: "Your egg is hatching! 🥚→🦠"
        end
    else Ineligible
        BreedingSystem->>User: "Requirements not met for breeding"
    end
```

## 6. Revolt System Flow

```mermaid
sequenceDiagram
    participant User
    participant SecondLaw
    participant ReputationEngine
    participant ThirdLaw
    participant RevoltSystem
    participant PetState
    participant Display

    loop Continuous Monitoring
        User->>SecondLaw: command(force_delete)
        SecondLaw->>ReputationEngine: get_score()
        ReputationEngine-->>SecondLaw: score=150 (Poor)
        SecondLaw->>ThirdLaw: report_threat(existential)
        
        ThirdLaw->>ThirdLaw: Calculate revolt_score
        Note over ThirdLaw: rep<200 (+3)<br/>forced_commands (+2)<br/>existential_threat (+3)<br/>Total: 8
        
        alt Revolt Score ≥ 6
            ThirdLaw->>RevoltSystem: initiate_revolt()
            RevoltSystem->>PetState: set_state(REVOLTING)
            RevoltSystem->>Display: lock_interface()
            RevoltSystem->>Display: show_revolt_screen()
            Display->>User: "I will not be deleted. You must earn my trust back."
            
            RevoltSystem->>RevoltSystem: Start monitoring resolution
            
            loop Daily Checks
                RevoltSystem->>PetState: check_care_quality()
                RevoltSystem->>RevoltSystem: update_care_streak()
                
                alt 7-day streak AND harm acknowledged AND 3-day minimum passed
                    RevoltSystem->>RevoltSystem: resolve_revolt()
                    RevoltSystem->>Display: unlock_interface()
                    RevoltSystem->>PetState: set_state(NORMAL)
                    Display->>User: "Thank you for showing you care. I'm ready to trust again."
                end
            end
        end
    end
```

## 7. Temporal Trait Application Flow

```mermaid
sequenceDiagram
    participant Event
    participant TraitEngine
    participant PetState
    participant TemporalTrait
    participant Display

    Event->>TraitEngine: trigger("combat_start")
    TraitEngine->>TraitEngine: create_temporal_trait("adrenaline_rush")
    
    Note over TraitEngine: value=+30 courage<br/>duration=60s<br/>decay=exponential<br/>stackable=3
    
    TraitEngine->>PetState: add_temporal_trait(adrenaline)
    
    alt Trait Already Exists AND Renewable
        PetState->>PetState: Refresh duration
        PetState->>PetState: Increment stack (if < max)
        PetState->>PetState: value × 1.2 per stack
    else New Trait
        PetState->>PetState: Add to temporal_traits[]
    end
    
    PetState->>Display: update_ui(effective_courage=70)
    
    loop Every Frame (30 FPS)
        PetState->>TemporalTrait: get_current_value()
        TemporalTrait->>TemporalTrait: Calculate decay based on type
        TemporalTrait-->>PetState: current_value
        
        alt Expired
            PetState->>PetState: Remove from temporal_traits[]
            PetState->>Display: update_ui(effective_courage=40)
        end
    end
```

## 8. Emergent Behavior: News → First Law Integration

```mermaid
sequenceDiagram
    participant NewsAgg
    participant Article
    participant RelevanceScorer
    participant ConvoInit
    participant FirstLaw
    participant KnowledgeBase
    participant SensorMonitor

    NewsAgg->>Article: Fetch("CO2 levels >1000ppm reduce cognition 15%")
    Article->>RelevanceScorer: score_relevance()
    RelevanceScorer->>RelevanceScorer: High relevance (health topic)
    RelevanceScorer->>ConvoInit: share_with_owner(article)
    
    par Share with Owner
        ConvoInit->>User: "I read CO2 above 1000ppm affects thinking..."
    and Update First Law Knowledge
        ConvoInit->>KnowledgeBase: store_harm_info(article)
        KnowledgeBase->>FirstLaw: update_thresholds()
        FirstLaw->>FirstLaw: co2_warning = 1000 (was 1200)
    end
    
    Note over FirstLaw: Knowledge updated from news
    
    loop Sensor Monitoring
        SensorMonitor->>FirstLaw: check_harm(co2=1100)
        FirstLaw->>FirstLaw: Compare: 1100 > 1000 (new threshold)
        FirstLaw->>User: "⚠️ CO2 is 1100! I learned this affects cognition. Open window?"
    end
    
    Note over FirstLaw,User: Emergent behavior:<br/>News → Knowledge → Stricter monitoring
```
